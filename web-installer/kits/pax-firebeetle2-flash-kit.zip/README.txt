Experimental firmware: hardware testing pending. DFR1172 ESP32-P4 model only. Requires ECA20-MHA1-I bridge and a correctly wired adapter. C6 Wi-Fi and SD are configured. Its PDM microphone is not speaker hardware, so audio output is omitted. Use a powered USB hub for USB inputs. Chip revision: 0/1; production rev3 needs a separate build.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-firebeetle2.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning. Dual-network profiles prefer Ethernet and fall back to provisioned Wi-Fi when the cable is disconnected. Ethernet-only boards use DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.

Copy both roms/ and backgrounds/ to the SD card root. The included blue gaming image is the default on new cards.
