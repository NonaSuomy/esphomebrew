Experimental firmware: hardware testing pending. Select the exact wiring. JC1060P470_I_W_Y uses LCD reset GPIO0, amplifier GPIO11, 2.7 V SD LDO4 and IP101 Ethernet DHCP. GT911 is polled; no unconfirmed touch reset/interrupt pins are driven. The earlier Wi-Fi reference retains LCD reset5, amplifier20, touch reset22/IRQ21 and SD passthrough. Both use native 1024x600 UI/app orientation and linear immediate backlight GPIO23. All variants are untested. Early revision 0/1 runs at 360 MHz; revision 3.0/X needs a separate firmware target.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-jc1060.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning. Dual-network profiles prefer Ethernet and fall back to provisioned Wi-Fi when the cable is disconnected. Ethernet-only boards use DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.

Copy both roms/ and backgrounds/ to the SD card root. The included blue gaming image is the default on new cards.
