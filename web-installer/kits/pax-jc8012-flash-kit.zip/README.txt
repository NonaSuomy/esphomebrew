Experimental firmware: hardware testing pending. 800x1280 JD9365 with the pinned GSL3680 touch driver. Touch orientation and all peripherals need hardware validation. Chip revision: 0/1; production rev3 needs a separate build.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-jc8012.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning; The nano720, nano1080 and eth-hdmi720 profiles use Ethernet DHCP; nano-wifi and m3-hdmi720 use hosted C6 Wi-Fi.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.
