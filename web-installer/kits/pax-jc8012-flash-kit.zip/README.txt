Experimental firmware: hardware testing pending. JC8012P4A1C_I_W_Y reference: JD9365 800x1280, 180-degree UI/app presentation, GSL3680 reset22/IRQ21 with mirror Y, LCD reset27 and linear immediate backlight on GPIO23. I2C7/8 uses external pull-ups. Uses the pinned GSL3680 driver. Hardware validation is pending. Early revision 0/1 runs at 360 MHz; revision 3.0/X needs its own firmware target.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-jc8012.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning. Dual-network profiles prefer Ethernet and fall back to provisioned Wi-Fi when the cable is disconnected. Ethernet-only boards use DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.

Copy both roms/ and backgrounds/ to the SD card root. The included blue gaming image is the default on new cards.
