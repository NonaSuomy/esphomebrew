Experimental firmware: hardware testing pending. Module Dev Kit with the supplied 10.1-inch JD9365/GT911 panel: 1280x800 landscape, 270-degree rotation and I2C panel power at 0x45. Ethernet DHCP with ESP32-C6 SDIO Wi-Fi fallback, four-bit SD and ES8311 speaker. Use the USB-to-UART programming port; select USB host jumpers as documented by Waveshare. 16MB flash, early P4 revision 0/1 at 360 MHz; rev3 needs a separate target. Display, touch, storage, networking and audio await hardware testing.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-module-devkit-lcd101.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning. Dual-network profiles prefer Ethernet and fall back to provisioned Wi-Fi when the cable is disconnected. Ethernet-only boards use DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.

Copy both roms/ and backgrounds/ to the SD card root. The included blue gaming image is the default on new cards.
