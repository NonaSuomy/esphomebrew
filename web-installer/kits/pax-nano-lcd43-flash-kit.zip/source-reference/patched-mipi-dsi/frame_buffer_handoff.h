#pragma once

#include <cstdint>

namespace esphome::mipi_dsi {

// Callers serialize access between the rendering task and the DMA interrupt.
class FrameBufferHandoff {
 public:
  void begin(uint8_t index) {
    pending_index_ = index;
    pending_ = true;
    completions_left_ = 0;
  }
  void submitted() {
    if (pending_ && completions_left_ == 0)
      completions_left_ = 2;
  }
  bool frame_complete() {
    if (!pending_ || completions_left_ == 0 || --completions_left_ != 0)
      return false;
    active_index_ = pending_index_;
    pending_ = false;
    return true;
  }
  void cancel() {
    pending_ = false;
    completions_left_ = 0;
  }
  bool pending() const { return pending_; }
  uint8_t back_index() const { return active_index_ ^ 1; }

 private:
  uint8_t active_index_{0};
  uint8_t pending_index_{0};
  uint8_t completions_left_{0};
  bool pending_{false};
};

}  // namespace esphome::mipi_dsi
