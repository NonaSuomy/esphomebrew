#ifdef USE_ESP32_VARIANT_ESP32P4
#include <utility>
#include "hal/mipi_dsi_host_ll.h"
#include "esp_chip_info.h"
#include <cstring>
#include "mipi_dsi.h"
#include "esphome/core/helpers.h"

namespace esphome {
namespace mipi_dsi {

// Maximum bytes to log for init commands (truncated if larger)
static constexpr size_t MIPI_DSI_MAX_CMD_LOG_BYTES = 64;

bool IRAM_ATTR MIPI_DSI::notify_refresh_ready(esp_lcd_panel_handle_t panel, esp_lcd_dpi_panel_event_data_t *edata,
                                              void *user_ctx) {
  (void) panel;
  (void) edata;
  auto *self = static_cast<MIPI_DSI *>(user_ctx);
  // IDF updates its requested scanout buffer before this callback. A frame
  // interrupt before this point must not release the previous front buffer.
  portENTER_CRITICAL_ISR(&self->frame_buffer_lock_);
  self->frame_buffer_handoff_.submitted();
  portEXIT_CRITICAL_ISR(&self->frame_buffer_lock_);
  BaseType_t need_yield = pdFALSE;
  xSemaphoreGiveFromISR(self->io_lock_, &need_yield);
  return (need_yield == pdTRUE);
}

bool IRAM_ATTR MIPI_DSI::notify_frame_buf_complete(esp_lcd_panel_handle_t panel, esp_lcd_dpi_panel_event_data_t *edata,
                                                   void *user_ctx) {
  (void) panel;
  (void) edata;
  auto *self = static_cast<MIPI_DSI *>(user_ctx);
  // DMA may have sampled the old requested buffer just before submission.
  // Two completions after submission guarantee it has selected the new one.
  portENTER_CRITICAL_ISR(&self->frame_buffer_lock_);
  const bool ready = self->frame_buffer_handoff_.frame_complete();
  portEXIT_CRITICAL_ISR(&self->frame_buffer_lock_);
  BaseType_t need_yield = pdFALSE;
  if (ready)
    xSemaphoreGiveFromISR(self->frame_buffer_ready_, &need_yield);
  return (need_yield == pdTRUE);
}

void MIPI_DSI::smark_failed(const LogString *message, esp_err_t err) {
  ESP_LOGE(TAG, "%s: %s", LOG_STR_ARG(message), esp_err_to_name(err));
  this->mark_failed(message);
}

void MIPI_DSI::setup() {
  ESP_LOGCONFIG(TAG, "Running Setup");

  if (!this->enable_pins_.empty()) {
    for (auto *pin : this->enable_pins_) {
      pin->setup();
      pin->digital_write(true);
    }
    // Allow the preconfigured bridge to start after power is enabled.
    delay(this->video_mode_only_ ? 100 : 10);
  }

  if (this->video_mode_only_ && this->reset_pin_ != nullptr) {
    this->reset_pin_->setup();
    this->reset_pin_->digital_write(false);
    delay(100);  // NOLINT: one-time vendor bridge reset pulse during setup.
    this->reset_pin_->digital_write(true);
    delay(200);  // NOLINT: one-time bridge firmware boot wait during setup.
  }

  esp_lcd_dsi_bus_config_t bus_config = {
      .bus_id = 0,  // index from 0, specify the DSI host to use
      .num_data_lanes =
          this->lanes_,  // Number of data lanes to use, can't set a value that exceeds the chip's capability
      .phy_clk_src = MIPI_DSI_PHY_CLK_SRC_DEFAULT,  // Clock source for the DPHY
      .lane_bit_rate_mbps = this->lane_bit_rate_,   // Bit rate of the data lanes, in Mbps
      .flags = {.clock_lane_force_hs = this->continuous_clock_},
  };
  auto err = esp_lcd_new_dsi_bus(&bus_config, &this->bus_handle_);
  if (err != ESP_OK) {
    this->smark_failed(LOG_STR("lcd_new_dsi_bus failed"), err);
    return;
  }
  if (!this->video_mode_only_) {
    esp_lcd_dbi_io_config_t dbi_config = {
        .virtual_channel = 0,
        .lcd_cmd_bits = 8,    // according to the LCD spec
        .lcd_param_bits = 8,  // according to the LCD spec
    };
    err = esp_lcd_new_panel_io_dbi(this->bus_handle_, &dbi_config, &this->io_handle_);
    if (err != ESP_OK) {
      this->smark_failed(LOG_STR("new_panel_io_dbi failed"), err);
      return;
    }
  }
  // ESP-IDF 6.1 renamed the MIPI-DPI color format enum and split the single
  // pixel_format field into input/output formats.
  auto pixel_format = LCD_COLOR_FMT_RGB565;
  if (this->color_depth_ == display::COLOR_BITNESS_888) {
    pixel_format = LCD_COLOR_FMT_RGB888;
  }
  // HDMI bridges can use RGB888 on the wire while retaining RGB565 app buffers.
  const auto output_format = this->video_mode_only_ && this->pixel_mode_ == 24 ? LCD_COLOR_FMT_RGB888 : pixel_format;
  esp_chip_info_t chip{};
  esp_chip_info(&chip);
  // Earlier P4 revisions share one format selector for input and output.
  this->software_rgb888_ =
      chip.revision < 300 && pixel_format == LCD_COLOR_FMT_RGB565 && output_format == LCD_COLOR_FMT_RGB888;
  if (this->software_rgb888_) {
    pixel_format = LCD_COLOR_FMT_RGB888;
    this->double_buffer_ = true;
    ESP_LOGI(TAG, "Using RGB565 software conversion to double-buffered RGB888 for P4 rev%u", chip.revision);
  }
  esp_lcd_dpi_panel_config_t dpi_config = {.virtual_channel = 0,
                                           .dpi_clk_src = MIPI_DSI_DPI_CLK_SRC_DEFAULT,
                                           .dpi_clock_freq_mhz = this->pclk_frequency_,
                                           .in_color_format = pixel_format,
                                           .out_color_format = output_format,
                                           .num_fbs = static_cast<uint8_t>(this->double_buffer_ ? 2 : 1),
                                           .video_timing =
                                               {
                                                   .h_size = this->width_,
                                                   .v_size = this->height_,
                                                   .hsync_pulse_width = this->hsync_pulse_width_,
                                                   .hsync_back_porch = this->hsync_back_porch_,
                                                   .hsync_front_porch = this->hsync_front_porch_,
                                                   .vsync_pulse_width = this->vsync_pulse_width_,
                                                   .vsync_back_porch = this->vsync_back_porch_,
                                                   .vsync_front_porch = this->vsync_front_porch_,
                                               },
                                           .flags = {}};
  err = esp_lcd_new_panel_dpi(this->bus_handle_, &dpi_config, &this->handle_);
  if (err != ESP_OK) {
    this->smark_failed(LOG_STR("esp_lcd_new_panel_dpi failed"), err);
    return;
  }
  if (this->double_buffer_) {
    void *fb0 = nullptr;
    void *fb1 = nullptr;
    err = esp_lcd_dpi_panel_get_frame_buffer(this->handle_, 2, &fb0, &fb1);
    if (err != ESP_OK || fb0 == nullptr || fb1 == nullptr) {
      this->smark_failed(LOG_STR("Could not get double frame buffers"), err != ESP_OK ? err : ESP_ERR_INVALID_STATE);
      return;
    }
    this->frame_buffers_[0] = static_cast<uint8_t *>(fb0);
    this->frame_buffers_[1] = static_cast<uint8_t *>(fb1);
    if (this->software_rgb888_) {
      std::memset(fb0, 0, this->width_ * this->height_ * 3);
      std::memset(fb1, 0, this->width_ * this->height_ * 3);
    }
    ESP_LOGI(TAG, "Double-buffered DSI scanout enabled (%zux%zu RGB%s)", this->width_, this->height_,
             this->software_rgb888_ || this->color_depth_ == display::COLOR_BITNESS_888 ? "888" : "565");
  }
  if (!this->video_mode_only_ && this->reset_pin_ != nullptr) {
    this->reset_pin_->setup();
    this->reset_pin_->digital_write(true);
    delay(5);
    this->reset_pin_->digital_write(false);
    delay(5);
    this->reset_pin_->digital_write(true);
  } else if (!this->video_mode_only_) {
    esp_lcd_panel_io_tx_param(this->io_handle_, SW_RESET_CMD, nullptr, 0);
  }
  // need to know when the display is ready for SLPOUT command - will be 120ms after reset
  auto when = millis() + 120;
  err = esp_lcd_panel_init(this->handle_);
  if (err != ESP_OK) {
    this->smark_failed(LOG_STR("esp_lcd_init failed"), err);
    return;
  }
  if (this->continuous_clock_) {
    // Panel init restores AUTO clock mode, so force continuous HS afterwards.
    mipi_dsi_host_ll_set_clock_lane_state(MIPI_DSI_LL_GET_HOST(0), MIPI_DSI_LL_CLOCK_LANE_STATE_HS);
  }
  size_t index = 0;
  auto &vec = this->init_sequence_;
  // Preconfigured DSI-to-HDMI bridges consume video without LCD DCS commands.
  while (!this->video_mode_only_ && index != vec.size()) {
    if (vec.size() - index < 2) {
      this->mark_failed(LOG_STR("Malformed init sequence"));
      return;
    }
    uint8_t cmd = vec[index++];
    uint8_t x = vec[index++];
    if (x == DELAY_FLAG) {
      ESP_LOGD(TAG, "Delay %dms", cmd);
      delay(cmd);
    } else {
      uint8_t num_args = x & 0x7F;
      if (vec.size() - index < num_args) {
        this->mark_failed(LOG_STR("Malformed init sequence"));
        return;
      }
      if (cmd == SLEEP_OUT) {
        // are we ready, boots?
        int duration = when - millis();
        if (duration > 0) {
          delay(duration);
        }
      }
      const auto *ptr = vec.data() + index;
#if ESPHOME_LOG_LEVEL >= ESPHOME_LOG_LEVEL_VERY_VERBOSE
      char hex_buf[format_hex_pretty_size(MIPI_DSI_MAX_CMD_LOG_BYTES)];
#endif
      ESP_LOGVV(TAG, "Command %02X, length %d, byte(s) %s", cmd, num_args,
                format_hex_pretty_to(hex_buf, ptr, num_args, '.'));
      err = esp_lcd_panel_io_tx_param(this->io_handle_, cmd, ptr, num_args);
      if (err != ESP_OK) {
        this->smark_failed(LOG_STR("lcd_panel_io_tx_param failed"), err);
        return;
      }
      index += num_args;
      if (cmd == SLEEP_OUT)
        delay(10);
    }
  }
  this->io_lock_ = xSemaphoreCreateBinary();
  if (this->double_buffer_) {
    this->frame_buffer_ready_ = xSemaphoreCreateBinary();
    if (this->frame_buffer_ready_ == nullptr) {
      this->smark_failed(LOG_STR("Could not allocate frame buffer semaphore"), ESP_ERR_NO_MEM);
      return;
    }
  }
  esp_lcd_dpi_panel_event_callbacks_t cbs = {
      .on_color_trans_done = notify_refresh_ready,
      .on_frame_buf_complete = this->double_buffer_ ? notify_frame_buf_complete : nullptr,
  };

  err = (esp_lcd_dpi_panel_register_event_callbacks(this->handle_, &cbs, this));
  if (err != ESP_OK) {
    this->smark_failed(LOG_STR("Failed to register callbacks"), err);
    return;
  }

  ESP_LOGCONFIG(TAG, "MIPI DSI setup complete");
}

void MIPI_DSI::update() {
  if (this->auto_clear_enabled_) {
    this->clear();
  }
  if (this->show_test_card_) {
    this->test_card();
  } else if (this->page_ != nullptr) {
    this->page_->get_writer()(*this);
  } else if (this->writer_.has_value()) {
    (*this->writer_)(*this);
  } else {
    this->stop_poller();
  }
  if (this->buffer_ == nullptr || this->x_low_ > this->x_high_ || this->y_low_ > this->y_high_)
    return;
  ESP_LOGV(TAG, "x_low %d, y_low %d, x_high %d, y_high %d", this->x_low_, this->y_low_, this->x_high_, this->y_high_);
  int w = this->x_high_ - this->x_low_ + 1;
  int h = this->y_high_ - this->y_low_ + 1;
  this->write_to_display_(this->x_low_, this->y_low_, w, h, this->buffer_, this->x_low_, this->y_low_,
                          this->width_ - w - this->x_low_);
  // invalidate watermarks
  this->x_low_ = this->width_;
  this->y_low_ = this->height_;
  this->x_high_ = 0;
  this->y_high_ = 0;
}

void MIPI_DSI::draw_pixels_at(int x_start, int y_start, int w, int h, const uint8_t *ptr, display::ColorOrder order,
                              display::ColorBitness bitness, bool big_endian, int x_offset, int y_offset, int x_pad) {
  if (w <= 0 || h <= 0)
    return;
  // if color mapping is required, pass the buck.
  // note that endianness is not considered here - it is assumed to match!
  if (bitness != this->color_depth_) {
    display::Display::draw_pixels_at(x_start, y_start, w, h, ptr, order, bitness, big_endian, x_offset, y_offset,
                                     x_pad);
    return;
  }
  this->write_to_display_(x_start, y_start, w, h, ptr, x_offset, y_offset, x_pad, big_endian);
}

bool MIPI_DSI::get_back_frame_buffer(uint16_t **frame_buffer) {
  if (this->software_rgb888_ || frame_buffer == nullptr || !this->double_buffer_ ||
      this->color_depth_ != display::COLOR_BITNESS_565 || this->frame_buffers_[0] == nullptr ||
      this->frame_buffers_[1] == nullptr || this->frame_buffer_ready_ == nullptr)
    return false;

  if (!this->wait_for_frame_buffer_())
    return false;
  portENTER_CRITICAL(&this->frame_buffer_lock_);
  const uint8_t back = this->frame_buffer_handoff_.back_index();
  portEXIT_CRITICAL(&this->frame_buffer_lock_);
  *frame_buffer = reinterpret_cast<uint16_t *>(this->frame_buffers_[back]);
  return true;
}

bool MIPI_DSI::wait_for_frame_buffer_() {
  while (true) {
    portENTER_CRITICAL(&this->frame_buffer_lock_);
    const bool pending = this->frame_buffer_handoff_.pending();
    portEXIT_CRITICAL(&this->frame_buffer_lock_);
    if (!pending)
      return true;
    if (xSemaphoreTake(this->frame_buffer_ready_, pdMS_TO_TICKS(100)) != pdTRUE) {
      ESP_LOGW(TAG, "Timed out waiting for DSI framebuffer handoff");
      return false;
    }
  }
}

void MIPI_DSI::write_to_display_(int x_start, int y_start, int w, int h, const uint8_t *ptr, int x_offset, int y_offset,
                                 int x_pad, bool big_endian) {
  // Partial writes (including overlays) must also wait for an earlier flip.
  if (!this->wait_for_frame_buffer_())
    return;
  if (this->software_rgb888_) {
    if (x_start < 0 || y_start < 0 || x_start + w > this->width_ || y_start + h > this->height_)
      return;
    portENTER_CRITICAL(&this->frame_buffer_lock_);
    const uint8_t back = this->frame_buffer_handoff_.back_index();
    portEXIT_CRITICAL(&this->frame_buffer_lock_);
    uint8_t *target = this->frame_buffers_[back];
    if (x_start != 0 || y_start != 0 || w != this->width_ || h != this->height_)
      std::memcpy(target, this->frame_buffers_[back ^ 1], this->width_ * this->height_ * 3);
    const size_t stride = (x_offset + w + x_pad) * 2;
    ptr += y_offset * stride + x_offset * 2;
    for (int y = 0; y < h; y++) {
      uint8_t *dest = target + ((y + y_start) * this->width_ + x_start) * 3;
      const uint8_t *source = ptr + y * stride;
      for (int x = 0; x < w; x++) {
        const uint16_t pixel = big_endian ? (source[0] << 8) | source[1] : source[0] | (source[1] << 8);
        const uint8_t blue = pixel & 31, green = (pixel >> 5) & 63, red = pixel >> 11;
        dest[0] = (blue << 3) | (blue >> 2);
        dest[1] = (green << 2) | (green >> 4);
        dest[2] = (red << 3) | (red >> 2);
        source += 2;
        dest += 3;
      }
    }
    portENTER_CRITICAL(&this->frame_buffer_lock_);
    this->frame_buffer_handoff_.begin(back);
    portEXIT_CRITICAL(&this->frame_buffer_lock_);
    const auto error = esp_lcd_panel_draw_bitmap(this->handle_, 0, 0, this->width_, this->height_, target);
    if (error == ESP_OK) {
      xSemaphoreTake(this->io_lock_, portMAX_DELAY);
    } else {
      portENTER_CRITICAL(&this->frame_buffer_lock_);
      this->frame_buffer_handoff_.cancel();
      portEXIT_CRITICAL(&this->frame_buffer_lock_);
      ESP_LOGE(TAG, "RGB888 frame presentation failed: %s", esp_err_to_name(error));
    }
    return;
  }
  esp_err_t err = ESP_OK;
  int requested_frame_buffer = -1;
  if (this->double_buffer_ && this->color_depth_ == display::COLOR_BITNESS_565 && x_start == 0 && y_start == 0 &&
      w == this->width_ && h == this->height_ && x_offset == 0 && y_offset == 0 && x_pad == 0) {
    for (int i = 0; i < 2; i++) {
      if (ptr == this->frame_buffers_[i]) {
        requested_frame_buffer = i;
        portENTER_CRITICAL(&this->frame_buffer_lock_);
        this->frame_buffer_handoff_.begin(static_cast<uint8_t>(i));
        portEXIT_CRITICAL(&this->frame_buffer_lock_);
        break;
      }
    }
  }
  auto bytes_per_pixel = 3 - this->color_depth_;
  auto stride = (x_offset + w + x_pad) * bytes_per_pixel;
  ptr += y_offset * stride + x_offset * bytes_per_pixel;  // skip to the first pixel
  // x_ and y_offset are offsets into the source buffer, unrelated to our own offsets into the display.
  if (x_offset == 0 && x_pad == 0) {
    err = esp_lcd_panel_draw_bitmap(this->handle_, x_start, y_start, x_start + w, y_start + h, ptr);
    if (err == ESP_OK)
      xSemaphoreTake(this->io_lock_, portMAX_DELAY);

  } else {
    // draw line by line
    for (int y = 0; y != h; y++) {
      err = esp_lcd_panel_draw_bitmap(this->handle_, x_start, y + y_start, x_start + w, y + y_start + 1, ptr);
      if (err != ESP_OK)
        break;
      ptr += stride;  // next line
      xSemaphoreTake(this->io_lock_, portMAX_DELAY);
    }
  }
  if (err != ESP_OK) {
    if (requested_frame_buffer >= 0) {
      portENTER_CRITICAL(&this->frame_buffer_lock_);
      this->frame_buffer_handoff_.cancel();
      portEXIT_CRITICAL(&this->frame_buffer_lock_);
    }
    ESP_LOGE(TAG, "lcd_lcd_panel_draw_bitmap failed: %s", esp_err_to_name(err));
  }
}

bool MIPI_DSI::check_buffer_() {
  if (this->is_failed())
    return false;
  if (this->buffer_ != nullptr)
    return true;
  // this is dependent on the enum values.
  auto bytes_per_pixel = 3 - this->color_depth_;
  RAMAllocator<uint8_t> allocator;
  this->buffer_ = allocator.allocate(this->height_ * this->width_ * bytes_per_pixel);
  if (this->buffer_ == nullptr) {
    this->mark_failed(LOG_STR("Could not allocate buffer for display!"));
    return false;
  }
  return true;
}

void MIPI_DSI::draw_pixel_at(int x, int y, Color color) {
  if (!this->get_clipping().inside(x, y))
    return;

  switch (this->rotation_) {
    case display::DISPLAY_ROTATION_0_DEGREES:
      break;
    case display::DISPLAY_ROTATION_90_DEGREES:
      std::swap(x, y);
      x = this->width_ - x - 1;
      break;
    case display::DISPLAY_ROTATION_180_DEGREES:
      x = this->width_ - x - 1;
      y = this->height_ - y - 1;
      break;
    case display::DISPLAY_ROTATION_270_DEGREES:
      std::swap(x, y);
      y = this->height_ - y - 1;
      break;
  }
  if (x >= this->get_width_internal() || x < 0 || y >= this->get_height_internal() || y < 0) {
    return;
  }
  auto pixel = convert_big_endian(display::ColorUtil::color_to_565(color));
  if (!this->check_buffer_())
    return;
  size_t pos = (y * this->width_) + x;
  switch (this->color_depth_) {
    case display::COLOR_BITNESS_565: {
      auto *ptr_16 = reinterpret_cast<uint16_t *>(this->buffer_);
      uint8_t hi_byte = static_cast<uint8_t>(color.r & 0xF8) | (color.g >> 5);
      uint8_t lo_byte = static_cast<uint8_t>((color.g & 0x1C) << 3) | (color.b >> 3);
      uint16_t new_color = lo_byte | (hi_byte << 8);  // little endian
      if (ptr_16[pos] == new_color)
        return;
      ptr_16[pos] = new_color;
      break;
    }
    case display::COLOR_BITNESS_888:
      if (this->color_mode_ == display::COLOR_ORDER_BGR) {
        this->buffer_[pos * 3] = color.b;
        this->buffer_[pos * 3 + 1] = color.g;
        this->buffer_[pos * 3 + 2] = color.r;
      } else {
        this->buffer_[pos * 3] = color.r;
        this->buffer_[pos * 3 + 1] = color.g;
        this->buffer_[pos * 3 + 2] = color.b;
      }
      break;
    case display::COLOR_BITNESS_332:
      break;
  }
  // low and high watermark may speed up drawing from buffer
  if (x < this->x_low_)
    this->x_low_ = x;
  if (y < this->y_low_)
    this->y_low_ = y;
  if (x > this->x_high_)
    this->x_high_ = x;
  if (y > this->y_high_)
    this->y_high_ = y;
}
void MIPI_DSI::fill(Color color) {
  if (!this->check_buffer_())
    return;

  // If clipping is active, fall back to base implementation
  if (this->get_clipping().is_set()) {
    Display::fill(color);
    return;
  }

  switch (this->color_depth_) {
    case display::COLOR_BITNESS_565: {
      auto *ptr_16 = reinterpret_cast<uint16_t *>(this->buffer_);
      uint8_t hi_byte = static_cast<uint8_t>(color.r & 0xF8) | (color.g >> 5);
      uint8_t lo_byte = static_cast<uint8_t>((color.g & 0x1C) << 3) | (color.b >> 3);
      uint16_t new_color = lo_byte | (hi_byte << 8);  // little endian
      std::fill_n(ptr_16, this->width_ * this->height_, new_color);
      break;
    }

    case display::COLOR_BITNESS_888:
      if (this->color_mode_ == display::COLOR_ORDER_BGR) {
        for (size_t i = 0; i != this->width_ * this->height_; i++) {
          this->buffer_[i * 3 + 0] = color.b;
          this->buffer_[i * 3 + 1] = color.g;
          this->buffer_[i * 3 + 2] = color.r;
        }
      } else {
        for (size_t i = 0; i != this->width_ * this->height_; i++) {
          this->buffer_[i * 3 + 0] = color.r;
          this->buffer_[i * 3 + 1] = color.g;
          this->buffer_[i * 3 + 2] = color.b;
        }
      }

    default:
      break;
  }
}

int MIPI_DSI::get_width() {
  switch (this->rotation_) {
    case display::DISPLAY_ROTATION_90_DEGREES:
    case display::DISPLAY_ROTATION_270_DEGREES:
      return this->get_height_internal();
    case display::DISPLAY_ROTATION_0_DEGREES:
    case display::DISPLAY_ROTATION_180_DEGREES:
    default:
      return this->get_width_internal();
  }
}

int MIPI_DSI::get_height() {
  switch (this->rotation_) {
    case display::DISPLAY_ROTATION_0_DEGREES:
    case display::DISPLAY_ROTATION_180_DEGREES:
      return this->get_height_internal();
    case display::DISPLAY_ROTATION_90_DEGREES:
    case display::DISPLAY_ROTATION_270_DEGREES:
    default:
      return this->get_width_internal();
  }
}

static const uint8_t PIXEL_MODES[] = {0, 16, 18, 24};

void MIPI_DSI::dump_config() {
  ESP_LOGCONFIG(TAG,
                "MIPI_DSI RGB LCD"
                "\n  Model: %s"
                "\n  Width: %u"
                "\n  Height: %u"
                "\n  Mirror X: %s"
                "\n  Mirror Y: %s"
                "\n  Swap X/Y: %s"
                "\n  Rotation: %d degrees"
                "\n  DSI Lanes: %u"
                "\n  Lane Bit Rate: %.0fMbps"
                "\n  HSync Pulse Width: %u"
                "\n  HSync Back Porch: %u"
                "\n  HSync Front Porch: %u"
                "\n  VSync Pulse Width: %u"
                "\n  VSync Back Porch: %u"
                "\n  VSync Front Porch: %u"
                "\n  Buffer Color Depth: %d bit"
                "\n  Display Pixel Mode: %d bit"
                "\n  Color Order: %s"
                "\n  Invert Colors: %s"
                "\n  Pixel Clock: %.1fMHz",
                this->model_, this->width_, this->height_, YESNO(this->madctl_ & (MADCTL_XFLIP | MADCTL_MX)),
                YESNO(this->madctl_ & (MADCTL_YFLIP | MADCTL_MY)), YESNO(this->madctl_ & MADCTL_MV), this->rotation_,
                this->lanes_, this->lane_bit_rate_, this->hsync_pulse_width_, this->hsync_back_porch_,
                this->hsync_front_porch_, this->vsync_pulse_width_, this->vsync_back_porch_, this->vsync_front_porch_,
                (3 - this->color_depth_) * 8, this->pixel_mode_, this->madctl_ & MADCTL_BGR ? "BGR" : "RGB",
                YESNO(this->invert_colors_), this->pclk_frequency_);
  ESP_LOGCONFIG(TAG, "  Video only: %s, continuous clock: %s", YESNO(this->video_mode_only_),
                YESNO(this->continuous_clock_));
  LOG_PIN("  Reset Pin ", this->reset_pin_);
}
}  // namespace mipi_dsi
}  // namespace esphome
#endif  // USE_ESP32_VARIANT_ESP32P4
