Experimental firmware: hardware testing pending. NANO HDMI needs ECA20-MHA1-I with two-lane input and correct adapter wiring. Audio uses the board codec, not HDMI.
Connect the programming USB port; hold BOOT and tap RESET if needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-nano1080.factory.bin
Copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning; NANO uses Ethernet DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.
