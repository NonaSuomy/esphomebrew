PAX nano720
Check your board and chip revision before flashing.
Factory install: python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-nano720.factory.bin
The OTA image is for an existing compatible PAX installation.
Copy roms/ and backgrounds/ to the SD card root, then choose STORAGE.
Public firmware contains no saved station credentials. Provision Wi-Fi or use supported Ethernet.
Compilation is verified by CI; hardware validation is separate.
