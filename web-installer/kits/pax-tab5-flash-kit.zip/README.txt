Experimental firmware: hardware testing pending. Original ILI9881C display and GT911 touch only. ST7123/ST7121 revisions need another profile. Programming uses USB Serial/JTAG. Chip revision: 0/1; production rev3 needs a separate build. To enter download mode, hold RESET for about two seconds until the green LED flashes, then release it.
Connect the programming USB port. Hold RESET for about two seconds until the green LED flashes, then release it. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-tab5.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning; The nano720, nano1080 and eth-hdmi720 profiles use Ethernet DHCP; nano-wifi and m3-hdmi720 use hosted C6 Wi-Fi.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.
