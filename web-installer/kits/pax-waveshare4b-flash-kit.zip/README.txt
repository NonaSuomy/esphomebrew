Experimental firmware: hardware testing pending. 720x720 ST7703 and GT911. Confirm the hosted C6 wiring against the exact PCB schematic: the supplied example and vendor signal summary differ. Chip revision: 0/1; production rev3 needs a separate build.
Connect the programming USB port. Hold BOOT and tap RESET if download mode is needed. Install esptool, then run:
python -m esptool --chip esp32p4 --port YOUR_PORT write-flash 0x0 pax-waveshare4b.factory.bin
After network setup, open http://DEVICE_IP:8080/pax to install the SD starter or upload local files. You can also copy roms/ to the root of your SD card. Wi-Fi boards support serial Improv provisioning. Dual-network profiles prefer Ethernet and fall back to provisioned Wi-Fi when the cable is disconnected. Ethernet-only boards use DHCP.
Source compilation: use the separate full PAX source installer package; these YAMLs depend on its patched components.
