Copy roms/ to the root of a FAT32 or exFAT SD card. Restart and choose STORAGE. Game data is installed separately.
